```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

df = pd.read_csv('healthcare_dataset.csv')
```


```python
# Data Cleaning
# Standardize text columns
df['Gender'] = df['Gender'].str.title()
df['Admission Type'] = df['Admission Type'].str.title()
df['Medical Condition'] = df['Medical Condition'].str.title()

# Handle negative billing
df['Billing Amount'] = df['Billing Amount'].abs()

# Convert dates
df['Date of Admission'] = pd.to_datetime(df['Date of Admission'])
df['Discharge Date'] = pd.to_datetime(df['Discharge Date'])
```


```python
# Calculate length of stay
df['Length of Stay'] = (df['Discharge Date'] - df['Date of Admission']).dt.days
```


```python
# Demographic Analysis
plt.figure(figsize=(10,6))
sns.histplot(df['Age'], bins=20, kde=True)
plt.title('Age Distribution')
plt.show()
```


    
![png](output_3_0.png)
    



```python
# Medical Condition Distribution
condition_counts = df['Medical Condition'].value_counts()
plt.figure(figsize=(12,6))
sns.barplot(x=condition_counts.values, y=condition_counts.index)
plt.title('Medical Condition Frequency')
plt.show()
```


    
![png](output_4_0.png)
    



```python
# Insurance Analysis
insurance_billing = df.groupby('Insurance Provider')['Billing Amount'].mean()
plt.figure(figsize=(10,6))
insurance_billing.sort_values().plot(kind='barh')
plt.title('Average Billing by Insurance Provider')
plt.show()
```


    
![png](output_5_0.png)
    



```python
# Test Result Correlation
plt.figure(figsize=(10,6))
sns.countplot(data=df, x='Medical Condition', hue='Test Results')
plt.xticks(rotation=45)
plt.title('Test Results by Medical Condition')
plt.show()
```


    
![png](output_6_0.png)
    



```python
# Temporal Analysis
df['Admission Month'] = df['Date of Admission'].dt.month_name()
monthly_admissions = df['Admission Month'].value_counts()
plt.figure(figsize=(10,6))
sns.lineplot(x=monthly_admissions.index, y=monthly_admissions.values)
plt.title('Monthly Admission Trends')
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_7_0.png)
    



```python
# Export cleaned data
df.to_csv('cleaned_healthcare_data.csv', index=False)
```

Patient Segmentation Clustering


```python
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
```


```python
# Prepare data
cluster_df = df[['Age', 'Billing Amount', 'Length of Stay', 'Room Number']]
cluster_df = pd.get_dummies(df[['Gender', 'Blood Type', 'Medical Condition']])

# Normalize
scaler = StandardScaler()
scaled_data = scaler.fit_transform(cluster_df)
```


```python
# Determine optimal clusters
wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, init='k-means++', random_state=42)
    kmeans.fit(scaled_data)
    wcss.append(kmeans.inertia_)
plt.plot(range(1,11), wcss)
plt.title('Elbow Method')
plt.show()

```

    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)
    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)



    
![png](output_12_1.png)
    



```python
# Apply K-means
kmeans = KMeans(n_clusters=4, init='k-means++', random_state=42)
clusters = kmeans.fit_predict(scaled_data)
```

    /Users/gaoshan/anaconda3/lib/python3.11/site-packages/sklearn/cluster/_kmeans.py:1412: FutureWarning: The default value of `n_init` will change from 10 to 'auto' in 1.4. Set the value of `n_init` explicitly to suppress the warning
      super()._check_params_vs_input(X, default_n_init=10)



```python
# Visualize with PCA
pca = PCA(n_components=2)
principal_components = pca.fit_transform(scaled_data)
plt.scatter(principal_components[:,0], principal_components[:,1], c=clusters)
plt.title('Patient Segmentation')
plt.show()
```


    
![png](output_14_0.png)
    


Readmission Risk Scoring System (Binary Classification)


```python
# Create readmission target (example: readmitted if same doctor within 30 days)
df = df.sort_values(['Name', 'Date of Admission'])
df['Next Admission'] = df.groupby('Name')['Date of Admission'].shift(-1)
df['Readmission'] = (df['Next Admission'] - df['Discharge Date']).dt.days <= 30
df['Readmission'] = df['Readmission'].fillna(False).astype(int)
```


```python
# Features and target
X = df.drop(['Readmission', 'Next Admission', 'Name', 'Date of Admission', 'Discharge Date'], axis=1)
y = df['Readmission']
```


```python
pip install xgboost
```

    Collecting xgboost
      Obtaining dependency information for xgboost from https://files.pythonhosted.org/packages/5a/0b/f9f815f240a9610d42367172b9f7ef7e8c9113a09b1bb35d4d85f96b910a/xgboost-3.0.0-py3-none-macosx_12_0_arm64.whl.metadata
      Downloading xgboost-3.0.0-py3-none-macosx_12_0_arm64.whl.metadata (2.1 kB)
    Requirement already satisfied: numpy in ./anaconda3/lib/python3.11/site-packages (from xgboost) (1.24.3)
    Requirement already satisfied: scipy in ./anaconda3/lib/python3.11/site-packages (from xgboost) (1.10.1)
    Downloading xgboost-3.0.0-py3-none-macosx_12_0_arm64.whl (2.0 MB)
    [2K   [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m2.0/2.0 MB[0m [31m23.1 MB/s[0m eta [36m0:00:00[0m00:01[0m00:01[0m
    [?25hInstalling collected packages: xgboost
    Successfully installed xgboost-3.0.0
    Note: you may need to restart the kernel to use updated packages.



```python
# Pipeline with XGBoost
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier
categorical_features = ['Gender', 'Blood Type', 'Medical Condition', 
                       'Doctor', 'Hospital', 'Insurance Provider',
                       'Admission Type', 'Medication']
numerical_features = ['Age', 'Billing Amount', 'Room Number', 'Length of Stay']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)]
)


model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', XGBClassifier(scale_pos_weight=len(y[y==0])/len(y[y==1])))
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model.fit(X_train, y_train)
```




<style>#sk-container-id-1 {color: black;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>Pipeline(steps=[(&#x27;preprocessor&#x27;,
                 ColumnTransformer(transformers=[(&#x27;num&#x27;, StandardScaler(),
                                                  [&#x27;Age&#x27;, &#x27;Billing Amount&#x27;,
                                                   &#x27;Room Number&#x27;,
                                                   &#x27;Length of Stay&#x27;]),
                                                 (&#x27;cat&#x27;,
                                                  OneHotEncoder(handle_unknown=&#x27;ignore&#x27;),
                                                  [&#x27;Gender&#x27;, &#x27;Blood Type&#x27;,
                                                   &#x27;Medical Condition&#x27;,
                                                   &#x27;Doctor&#x27;, &#x27;Hospital&#x27;,
                                                   &#x27;Insurance Provider&#x27;,
                                                   &#x27;Admission Type&#x27;,
                                                   &#x27;Medication&#x27;])])),
                (&#x27;classifier&#x27;,
                 XGBClassifier(base_score=None, boos...
                               feature_types=None, feature_weights=None,
                               gamma=None, grow_policy=None,
                               importance_type=None,
                               interaction_constraints=None, learning_rate=None,
                               max_bin=None, max_cat_threshold=None,
                               max_cat_to_onehot=None, max_delta_step=None,
                               max_depth=None, max_leaves=None,
                               min_child_weight=None, missing=nan,
                               monotone_constraints=None, multi_strategy=None,
                               n_estimators=None, n_jobs=None,
                               num_parallel_tree=None, ...))])</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" ><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">Pipeline</label><div class="sk-toggleable__content"><pre>Pipeline(steps=[(&#x27;preprocessor&#x27;,
                 ColumnTransformer(transformers=[(&#x27;num&#x27;, StandardScaler(),
                                                  [&#x27;Age&#x27;, &#x27;Billing Amount&#x27;,
                                                   &#x27;Room Number&#x27;,
                                                   &#x27;Length of Stay&#x27;]),
                                                 (&#x27;cat&#x27;,
                                                  OneHotEncoder(handle_unknown=&#x27;ignore&#x27;),
                                                  [&#x27;Gender&#x27;, &#x27;Blood Type&#x27;,
                                                   &#x27;Medical Condition&#x27;,
                                                   &#x27;Doctor&#x27;, &#x27;Hospital&#x27;,
                                                   &#x27;Insurance Provider&#x27;,
                                                   &#x27;Admission Type&#x27;,
                                                   &#x27;Medication&#x27;])])),
                (&#x27;classifier&#x27;,
                 XGBClassifier(base_score=None, boos...
                               feature_types=None, feature_weights=None,
                               gamma=None, grow_policy=None,
                               importance_type=None,
                               interaction_constraints=None, learning_rate=None,
                               max_bin=None, max_cat_threshold=None,
                               max_cat_to_onehot=None, max_delta_step=None,
                               max_depth=None, max_leaves=None,
                               min_child_weight=None, missing=nan,
                               monotone_constraints=None, multi_strategy=None,
                               n_estimators=None, n_jobs=None,
                               num_parallel_tree=None, ...))])</pre></div></div></div><div class="sk-serial"><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" ><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">preprocessor: ColumnTransformer</label><div class="sk-toggleable__content"><pre>ColumnTransformer(transformers=[(&#x27;num&#x27;, StandardScaler(),
                                 [&#x27;Age&#x27;, &#x27;Billing Amount&#x27;, &#x27;Room Number&#x27;,
                                  &#x27;Length of Stay&#x27;]),
                                (&#x27;cat&#x27;, OneHotEncoder(handle_unknown=&#x27;ignore&#x27;),
                                 [&#x27;Gender&#x27;, &#x27;Blood Type&#x27;, &#x27;Medical Condition&#x27;,
                                  &#x27;Doctor&#x27;, &#x27;Hospital&#x27;, &#x27;Insurance Provider&#x27;,
                                  &#x27;Admission Type&#x27;, &#x27;Medication&#x27;])])</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" ><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">num</label><div class="sk-toggleable__content"><pre>[&#x27;Age&#x27;, &#x27;Billing Amount&#x27;, &#x27;Room Number&#x27;, &#x27;Length of Stay&#x27;]</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" ><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">StandardScaler</label><div class="sk-toggleable__content"><pre>StandardScaler()</pre></div></div></div></div></div></div><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-5" type="checkbox" ><label for="sk-estimator-id-5" class="sk-toggleable__label sk-toggleable__label-arrow">cat</label><div class="sk-toggleable__content"><pre>[&#x27;Gender&#x27;, &#x27;Blood Type&#x27;, &#x27;Medical Condition&#x27;, &#x27;Doctor&#x27;, &#x27;Hospital&#x27;, &#x27;Insurance Provider&#x27;, &#x27;Admission Type&#x27;, &#x27;Medication&#x27;]</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-6" type="checkbox" ><label for="sk-estimator-id-6" class="sk-toggleable__label sk-toggleable__label-arrow">OneHotEncoder</label><div class="sk-toggleable__content"><pre>OneHotEncoder(handle_unknown=&#x27;ignore&#x27;)</pre></div></div></div></div></div></div></div></div><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">XGBClassifier</label><div class="sk-toggleable__content"><pre>XGBClassifier(base_score=None, booster=None, callbacks=None,
              colsample_bylevel=None, colsample_bynode=None,
              colsample_bytree=None, device=None, early_stopping_rounds=None,
              enable_categorical=False, eval_metric=None, feature_types=None,
              feature_weights=None, gamma=None, grow_policy=None,
              importance_type=None, interaction_constraints=None,
              learning_rate=None, max_bin=None, max_cat_threshold=None,
              max_cat_to_onehot=None, max_delta_step=None, max_depth=None,
              max_leaves=None, min_child_weight=None, missing=nan,
              monotone_constraints=None, multi_strategy=None, n_estimators=None,
              n_jobs=None, num_parallel_tree=None, ...)</pre></div></div></div></div></div></div></div>




```python
# Feature importance
importances = model.named_steps['classifier'].feature_importances_
features = model.named_steps['preprocessor'].get_feature_names_out()
pd.Series(importances, index=features).sort_values(ascending=False).head(10).plot(kind='barh')
plt.title('Top 10 Readmission Risk Factors')
plt.show()
```


    
![png](output_20_0.png)
    


Doctor Performance Analysis


```python
# Create performance metrics
doctor_stats = df.groupby('Doctor').agg({
    'Billing Amount': 'mean',
    'Test Results': lambda x: (x == 'Normal').mean(),
    'Length of Stay': 'median',
    'Readmission': 'mean',
    'Name': 'count'
}).rename(columns={'Name': 'Patient Count'})
```


```python
# Normalize metrics
doctor_stats['Performance Score'] = (
    0.4 * (1 - doctor_stats['Readmission']) +
    0.3 * doctor_stats['Test Results'] +
    0.2 * (1 / doctor_stats['Length of Stay']) +
    0.1 * (1 / doctor_stats['Billing Amount'])
)
```


```python
# Top 10 doctors
doctor_stats.sort_values('Performance Score', ascending=False).head(10).style.background_gradient()
```




<style type="text/css">
#T_2fd20_row0_col0, #T_2fd20_row0_col1, #T_2fd20_row0_col2, #T_2fd20_row0_col3, #T_2fd20_row0_col4, #T_2fd20_row1_col1, #T_2fd20_row1_col2, #T_2fd20_row1_col3, #T_2fd20_row1_col4, #T_2fd20_row2_col1, #T_2fd20_row2_col2, #T_2fd20_row2_col3, #T_2fd20_row2_col4, #T_2fd20_row3_col1, #T_2fd20_row3_col2, #T_2fd20_row3_col3, #T_2fd20_row3_col4, #T_2fd20_row4_col1, #T_2fd20_row4_col2, #T_2fd20_row4_col3, #T_2fd20_row4_col4, #T_2fd20_row5_col1, #T_2fd20_row5_col2, #T_2fd20_row5_col3, #T_2fd20_row5_col4, #T_2fd20_row6_col1, #T_2fd20_row6_col2, #T_2fd20_row6_col3, #T_2fd20_row6_col4, #T_2fd20_row7_col1, #T_2fd20_row7_col2, #T_2fd20_row7_col3, #T_2fd20_row7_col4, #T_2fd20_row8_col1, #T_2fd20_row8_col2, #T_2fd20_row8_col3, #T_2fd20_row8_col4, #T_2fd20_row9_col1, #T_2fd20_row9_col2, #T_2fd20_row9_col3, #T_2fd20_row9_col4, #T_2fd20_row9_col5 {
  background-color: #fff7fb;
  color: #000000;
}
#T_2fd20_row0_col5, #T_2fd20_row9_col0 {
  background-color: #023858;
  color: #f1f1f1;
}
#T_2fd20_row1_col0 {
  background-color: #dddbec;
  color: #000000;
}
#T_2fd20_row1_col5 {
  background-color: #dbdaeb;
  color: #000000;
}
#T_2fd20_row2_col0 {
  background-color: #a1bbda;
  color: #000000;
}
#T_2fd20_row2_col5 {
  background-color: #f2ecf5;
  color: #000000;
}
#T_2fd20_row3_col0 {
  background-color: #94b6d7;
  color: #000000;
}
#T_2fd20_row3_col5 {
  background-color: #f4edf6;
  color: #000000;
}
#T_2fd20_row4_col0 {
  background-color: #5ea0ca;
  color: #f1f1f1;
}
#T_2fd20_row4_col5 {
  background-color: #f8f1f8;
  color: #000000;
}
#T_2fd20_row5_col0 {
  background-color: #358fc0;
  color: #f1f1f1;
}
#T_2fd20_row5_col5 {
  background-color: #faf3f9;
  color: #000000;
}
#T_2fd20_row6_col0 {
  background-color: #1b7eb7;
  color: #f1f1f1;
}
#T_2fd20_row6_col5 {
  background-color: #fbf4f9;
  color: #000000;
}
#T_2fd20_row7_col0 {
  background-color: #0c74b2;
  color: #f1f1f1;
}
#T_2fd20_row7_col5 {
  background-color: #fcf4fa;
  color: #000000;
}
#T_2fd20_row8_col0 {
  background-color: #056ba9;
  color: #f1f1f1;
}
#T_2fd20_row8_col5 {
  background-color: #fdf5fa;
  color: #000000;
}
</style>
<table id="T_2fd20">
  <thead>
    <tr>
      <th class="blank level0" >&nbsp;</th>
      <th id="T_2fd20_level0_col0" class="col_heading level0 col0" >Billing Amount</th>
      <th id="T_2fd20_level0_col1" class="col_heading level0 col1" >Test Results</th>
      <th id="T_2fd20_level0_col2" class="col_heading level0 col2" >Length of Stay</th>
      <th id="T_2fd20_level0_col3" class="col_heading level0 col3" >Readmission</th>
      <th id="T_2fd20_level0_col4" class="col_heading level0 col4" >Patient Count</th>
      <th id="T_2fd20_level0_col5" class="col_heading level0 col5" >Performance Score</th>
    </tr>
    <tr>
      <th class="index_name level0" >Doctor</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
      <th class="blank col3" >&nbsp;</th>
      <th class="blank col4" >&nbsp;</th>
      <th class="blank col5" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_2fd20_level0_row0" class="row_heading level0 row0" >Jesse Cervantes</th>
      <td id="T_2fd20_row0_col0" class="data row0 col0" >172.613392</td>
      <td id="T_2fd20_row0_col1" class="data row0 col1" >1.000000</td>
      <td id="T_2fd20_row0_col2" class="data row0 col2" >1.000000</td>
      <td id="T_2fd20_row0_col3" class="data row0 col3" >0.000000</td>
      <td id="T_2fd20_row0_col4" class="data row0 col4" >1</td>
      <td id="T_2fd20_row0_col5" class="data row0 col5" >0.900579</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row1" class="row_heading level0 row1" >Stephen Stokes</th>
      <td id="T_2fd20_row1_col0" class="data row1 col0" >695.733635</td>
      <td id="T_2fd20_row1_col1" class="data row1 col1" >1.000000</td>
      <td id="T_2fd20_row1_col2" class="data row1 col2" >1.000000</td>
      <td id="T_2fd20_row1_col3" class="data row1 col3" >0.000000</td>
      <td id="T_2fd20_row1_col4" class="data row1 col4" >1</td>
      <td id="T_2fd20_row1_col5" class="data row1 col5" >0.900144</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row2" class="row_heading level0 row2" >Wanda Bryant</th>
      <td id="T_2fd20_row2_col0" class="data row2 col0" >1222.152056</td>
      <td id="T_2fd20_row2_col1" class="data row2 col1" >1.000000</td>
      <td id="T_2fd20_row2_col2" class="data row2 col2" >1.000000</td>
      <td id="T_2fd20_row2_col3" class="data row2 col3" >0.000000</td>
      <td id="T_2fd20_row2_col4" class="data row2 col4" >1</td>
      <td id="T_2fd20_row2_col5" class="data row2 col5" >0.900082</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row3" class="row_heading level0 row3" >Richard Wilcox</th>
      <td id="T_2fd20_row3_col0" class="data row3 col0" >1299.118219</td>
      <td id="T_2fd20_row3_col1" class="data row3 col1" >1.000000</td>
      <td id="T_2fd20_row3_col2" class="data row3 col2" >1.000000</td>
      <td id="T_2fd20_row3_col3" class="data row3 col3" >0.000000</td>
      <td id="T_2fd20_row3_col4" class="data row3 col4" >1</td>
      <td id="T_2fd20_row3_col5" class="data row3 col5" >0.900077</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row4" class="row_heading level0 row4" >Willie Blake</th>
      <td id="T_2fd20_row4_col0" class="data row4 col0" >1638.277998</td>
      <td id="T_2fd20_row4_col1" class="data row4 col1" >1.000000</td>
      <td id="T_2fd20_row4_col2" class="data row4 col2" >1.000000</td>
      <td id="T_2fd20_row4_col3" class="data row4 col3" >0.000000</td>
      <td id="T_2fd20_row4_col4" class="data row4 col4" >1</td>
      <td id="T_2fd20_row4_col5" class="data row4 col5" >0.900061</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row5" class="row_heading level0 row5" >Lisa Richard</th>
      <td id="T_2fd20_row5_col0" class="data row5 col0" >1858.519099</td>
      <td id="T_2fd20_row5_col1" class="data row5 col1" >1.000000</td>
      <td id="T_2fd20_row5_col2" class="data row5 col2" >1.000000</td>
      <td id="T_2fd20_row5_col3" class="data row5 col3" >0.000000</td>
      <td id="T_2fd20_row5_col4" class="data row5 col4" >1</td>
      <td id="T_2fd20_row5_col5" class="data row5 col5" >0.900054</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row6" class="row_heading level0 row6" >Julia Shelton</th>
      <td id="T_2fd20_row6_col0" class="data row6 col0" >2036.377712</td>
      <td id="T_2fd20_row6_col1" class="data row6 col1" >1.000000</td>
      <td id="T_2fd20_row6_col2" class="data row6 col2" >1.000000</td>
      <td id="T_2fd20_row6_col3" class="data row6 col3" >0.000000</td>
      <td id="T_2fd20_row6_col4" class="data row6 col4" >1</td>
      <td id="T_2fd20_row6_col5" class="data row6 col5" >0.900049</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row7" class="row_heading level0 row7" >Amy Greer</th>
      <td id="T_2fd20_row7_col0" class="data row7 col0" >2142.956280</td>
      <td id="T_2fd20_row7_col1" class="data row7 col1" >1.000000</td>
      <td id="T_2fd20_row7_col2" class="data row7 col2" >1.000000</td>
      <td id="T_2fd20_row7_col3" class="data row7 col3" >0.000000</td>
      <td id="T_2fd20_row7_col4" class="data row7 col4" >1</td>
      <td id="T_2fd20_row7_col5" class="data row7 col5" >0.900047</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row8" class="row_heading level0 row8" >Sarah Carter</th>
      <td id="T_2fd20_row8_col0" class="data row8 col0" >2257.090196</td>
      <td id="T_2fd20_row8_col1" class="data row8 col1" >1.000000</td>
      <td id="T_2fd20_row8_col2" class="data row8 col2" >1.000000</td>
      <td id="T_2fd20_row8_col3" class="data row8 col3" >0.000000</td>
      <td id="T_2fd20_row8_col4" class="data row8 col4" >1</td>
      <td id="T_2fd20_row8_col5" class="data row8 col5" >0.900044</td>
    </tr>
    <tr>
      <th id="T_2fd20_level0_row9" class="row_heading level0 row9" >Tammy Salazar</th>
      <td id="T_2fd20_row9_col0" class="data row9 col0" >2861.367332</td>
      <td id="T_2fd20_row9_col1" class="data row9 col1" >1.000000</td>
      <td id="T_2fd20_row9_col2" class="data row9 col2" >1.000000</td>
      <td id="T_2fd20_row9_col3" class="data row9 col3" >0.000000</td>
      <td id="T_2fd20_row9_col4" class="data row9 col4" >1</td>
      <td id="T_2fd20_row9_col5" class="data row9 col5" >0.900035</td>
    </tr>
  </tbody>
</table>




Cost-Effectiveness Analysis


```python
# Group by medical condition and medication
cost_effectiveness = df.groupby(['Medical Condition', 'Medication']).agg({
    'Billing Amount': 'mean',
    'Test Results': lambda x: (x == 'Normal').mean()
}).reset_index()
```


```python
# Calculate cost-effectiveness ratio
cost_effectiveness['Cost per Success'] = cost_effectiveness['Billing Amount'] / cost_effectiveness['Test Results']
```


```python
# Visualize
plt.figure(figsize=(12,8))
sns.scatterplot(data=cost_effectiveness, x='Test Results', y='Billing Amount',
                hue='Medical Condition', size='Cost per Success', sizes=(20, 200))
plt.title('Cost-Effectiveness Analysis')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.show()
```


    
![png](output_28_0.png)
    

